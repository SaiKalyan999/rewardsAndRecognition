package com.example.testnine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestnineApplication {

	public static void main(String[] args) { SpringApplication.run(TestnineApplication.class, args);


}
