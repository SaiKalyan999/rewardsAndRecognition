package com.example.testnine.Repository;
import org.springframework.stereotype.Repository;

@Repository

public interface IdenRepository extends JpaRepository<Enty, String>{


}
